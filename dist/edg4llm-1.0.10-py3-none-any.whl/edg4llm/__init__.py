from edg4llm.core.interface import EDG4LLM
from edg4llm.post_install import display_ascii_art

__all__ = ["EDG4LLM", "display_ascii_art"]

__version__ = "1.0.10"
__author__ = "Alannikos"
__license__ = "MIT"
