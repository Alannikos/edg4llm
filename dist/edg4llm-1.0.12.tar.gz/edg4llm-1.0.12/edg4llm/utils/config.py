import dataclasses

@dataclasses
class DefaultConfig:
    """
    A placeholder class for default configuration settings.
    """
    pass
