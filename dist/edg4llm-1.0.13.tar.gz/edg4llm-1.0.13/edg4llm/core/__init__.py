from edg4llm.core.interface import EDG4LLM
