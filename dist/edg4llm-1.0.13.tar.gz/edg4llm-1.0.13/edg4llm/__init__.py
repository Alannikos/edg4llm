from edg4llm.core.interface import EDG4LLM

__all__ = ["EDG4LLM"]

__version__ = "1.0.13"
__author__ = "Alannikos"
__license__ = "MIT"
